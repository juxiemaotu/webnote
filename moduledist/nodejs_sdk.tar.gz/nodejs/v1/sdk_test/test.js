
var t = new Date();
console.log(t);

var sub = "sub";
var subtext = "subtext"

console.log(subtext.indexOf(sub) === 0);


console.log("FXFF".toLowerCase());
